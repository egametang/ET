﻿using System;

namespace ET
{
    public class NoMemoryCheck: Attribute
    {
    }
}