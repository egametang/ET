﻿using System;

namespace Newtonsoft.Json.Shims
{
    [Preserve]
    public class PreserveAttribute : Attribute
    {
    }
}
